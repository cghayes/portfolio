// JavaScript Document

document.write("<div style='text-align:center;'>");
document.write("<a href='about.htm'>About</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href='rules.htm'>Rules</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href='submit.htm'>Submit</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href='vote.htm'>Vote</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href='winners.htm'>Winners</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp <a href='chat.htm'>Chat&nbsp;Room</a>");
document.write("</div>");